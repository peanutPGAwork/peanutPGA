The in-house  scripts  of  peanut proteogenomics work:

#Step 1    Find the novel peptides:
#from search result, using seprateFDR method to get the novel peptide.
perl pga.pl  msgfplus-peptideSummary.txt      #output: novel_peptide  

#Step 2   get the location of novel peptides
 
#Step 3   get the different kinds of novel  events

Any question, please contact zhouruo@deepxomics.com
